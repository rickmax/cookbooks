default['packages-cookbook'] = []
default['packages-cookbook_default_action'] = 'install'
